const apiBaseUrl = window._env_?.REACT_APP_WEB_API_URL || process.env.REACT_APP_WEB_API_URL || "https://default-api-url.com";

export default apiBaseUrl;
